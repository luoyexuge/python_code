#encoding:utf-8
'''
Created on 2015年12月2日

@author: wilson.zhou
'''

import urllib
#url编码的问题
url = 'http://test.com/s?wd=哈哈'

url=url.decode('gbk','repalce')

print urllib.quote(url.encode('utf-8','replace'))
#http%3A//test.com/s%3Fwd%3D%E9%8D%9D%E5%A0%9D%E6%90%B1

#url解码的问题
test='http%3A//test.com/s%3Fwd%3D%E9%8D%9D%E5%A0%9D%E6%90%B1'

print urllib.unquote(test)
# http://test.com/s?wd=鍝堝搱   会出现梵文的情况

print urllib.unquote(test).decode('utf-8', 'replace').encode('gbk', 'replace')
#http://test.com/s?wd=哈哈

